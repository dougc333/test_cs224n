

def say_hello(name=None):
	if name is None:
		return "hello none"
	else:
		return f"hello {name}"


